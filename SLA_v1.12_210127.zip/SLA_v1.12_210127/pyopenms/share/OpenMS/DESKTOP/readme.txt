The files in this directory represent meta-data files required for some Linux distributions 
and their packaging mechanics.

For details on the *.appdata.xml files see:
https://fedoraproject.org/wiki/Packaging:AppData
